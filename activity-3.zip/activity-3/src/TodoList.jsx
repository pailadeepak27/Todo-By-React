import { useState } from "react";
import { v4 as uuidv4 } from 'uuid'; // for unique id

export default function TodoList(){
    let [todos, setTodos] = useState([{ task : "Simple Task", id : uuidv4()}]);   // For intial State uuid used for unique id
    let [newTodo, setnewTodo] = useState("");  // value 

    const addnewTask = () => { // render to button to list
        setTodos([...todos,  {task : newTodo, id : uuidv4()}]);
        setnewTodo(""); // Set Input to empty string after write
       
    }

    let UpdateTask=(event)=>{  //  update the task
     setnewTodo(event.target.value);
    }

     let deleteTodo = (id) => {
           setTodos((prviousTodo) => todos.filter((prviousTodo) => prviousTodo.id != id));
     };
     
     let UpprCaseAll = ()=>{

        setTodos(
            todos.map((todo)=>{
                return{
                    ...todos,
                    task: todo.task.toUpperCase()
                }
            } )
        );

     };
    

    return(
    
        <div>
            <h1>Todo List</h1>
            <br />
            <br />
            <br />
            <input
             placeholder="Write A Task"
               value={newTodo} 
               onChange={UpdateTask}
               style={{ height: 30, width: 200 }}/>

            <button onClick={addnewTask}> Add Task</button>
            <br />
            <br />
            <hr />
            <h3>Task ToDo</h3>
             <ul>
           {
           todos.map((todo) => (       // key is use for unique id
                  <li key={todo.id}> 
                    <span>{todo.task}</span>
                    &nbsp;  &nbsp;  &nbsp;
                    <button onClick={()=>deleteTodo(prviousTodo.id)}>Delete</button>
                    
                    </li> 
             ))
             }
            </ul>
            <button onClick={UpprCaseAll}>UpperCase All</button> 
            
        </div>
        
    );
}
